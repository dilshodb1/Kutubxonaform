﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kutubxona
{
    public partial class Ma_lumotlar_bazasi : Form
    {
        public Ma_lumotlar_bazasi()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void btkitoblar_Click(object sender, EventArgs e)
        {
            this.Hide();
            Badiiy_kitoblar ob1 = new Badiiy_kitoblar();
            ob1.Show();
        }

        private void btArxiv_Statistic_Click(object sender, EventArgs e)
        {
            this.Hide();
            Arxiv_Sts ob1 = new Arxiv_Sts();
            ob1.Show();
        }

        private void btDasturlash_Click(object sender, EventArgs e)
        {
            this.Hide();
            Dasturlaw ob = new Dasturlaw();
            ob.Show();
        }

        private void btk_oliw_Click(object sender, EventArgs e)
        {
            this.Hide();
            K_olish ob = new K_olish();
            ob.Show();
        }

        private void btk_qaytarish_Click(object sender, EventArgs e)
        {
            this.Hide();
            K_Qaytarish ob = new K_Qaytarish();
            ob.Show();
        }

        private void btm_book_Click(object sender, EventArgs e)
        {
            this.Hide();
            Math_book ob = new Math_book();
            ob.Show();
        }
    }
}
