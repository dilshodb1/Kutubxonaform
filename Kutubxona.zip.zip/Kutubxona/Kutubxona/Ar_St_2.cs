﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kutubxona
{
    public partial class Ar_St_2 : Form
    {
        public Ar_St_2()
        {
            InitializeComponent();
        }

        private void Ar_St_2_Load(object sender, EventArgs e)
        {
            if (Arxiv_Sts.Passport)
            {
                lbChangeDoc.Text = "Pasport No :";
                lbChangeDocExpDate.Text = "Pasport Expiry Date :";
            }
            if (Arxiv_Sts.IDCard)
            {
                lbChangeDoc.Text = "ID Card No :";
                lbChangeDocExpDate.Text = "ID Card Expiry Date :";
            }

            lbFullName.Text = Arxiv_Sts.firstName + " " + Arxiv_Sts.LastName;
            lbDepartureCity.Text = Arxiv_Sts.From;
            lbDestinationCity.Text = Arxiv_Sts.To;
            lbTripDates.Text = Arxiv_Sts.StartTripDate + " to " + Arxiv_Sts.EndTripDate;
            lbDocumentNo.Text = Arxiv_Sts.DocumentNo;
            lbDocExpDate.Text = Arxiv_Sts.Expirydate;
            lbBaggageWeight.Text = Arxiv_Sts.WeightBaggage;
        }

        private void btDone_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
