﻿namespace Kutubxona
{
    partial class Ma_lumotlar_bazasi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btkitoblar = new System.Windows.Forms.Button();
            this.btArxiv_Statistic = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btDasturlash = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.btk_oliw = new System.Windows.Forms.Button();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.btk_qaytarish = new System.Windows.Forms.Button();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.btm_book = new System.Windows.Forms.Button();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Kutubxona.Properties.Resources.Screenshot_20231209_200857_Google;
            this.pictureBox1.Location = new System.Drawing.Point(135, 48);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(274, 164);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // btkitoblar
            // 
            this.btkitoblar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btkitoblar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btkitoblar.ForeColor = System.Drawing.Color.Black;
            this.btkitoblar.Location = new System.Drawing.Point(135, 218);
            this.btkitoblar.Name = "btkitoblar";
            this.btkitoblar.Size = new System.Drawing.Size(274, 60);
            this.btkitoblar.TabIndex = 1;
            this.btkitoblar.Text = "Badiiy Kitoblar";
            this.btkitoblar.UseVisualStyleBackColor = false;
            this.btkitoblar.Click += new System.EventHandler(this.btkitoblar_Click);
            // 
            // btArxiv_Statistic
            // 
            this.btArxiv_Statistic.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btArxiv_Statistic.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btArxiv_Statistic.ForeColor = System.Drawing.Color.Black;
            this.btArxiv_Statistic.Location = new System.Drawing.Point(545, 218);
            this.btArxiv_Statistic.Name = "btArxiv_Statistic";
            this.btArxiv_Statistic.Size = new System.Drawing.Size(274, 60);
            this.btArxiv_Statistic.TabIndex = 3;
            this.btArxiv_Statistic.Text = "Arxiv va Statistika";
            this.btArxiv_Statistic.UseVisualStyleBackColor = false;
            this.btArxiv_Statistic.Click += new System.EventHandler(this.btArxiv_Statistic_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Kutubxona.Properties.Resources.Screenshot_20231211_213810_Google;
            this.pictureBox2.Location = new System.Drawing.Point(545, 48);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(274, 164);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // btDasturlash
            // 
            this.btDasturlash.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btDasturlash.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btDasturlash.ForeColor = System.Drawing.Color.Black;
            this.btDasturlash.Location = new System.Drawing.Point(961, 218);
            this.btDasturlash.Name = "btDasturlash";
            this.btDasturlash.Size = new System.Drawing.Size(274, 60);
            this.btDasturlash.TabIndex = 5;
            this.btDasturlash.Text = "Dasturlash";
            this.btDasturlash.UseVisualStyleBackColor = false;
            this.btDasturlash.Click += new System.EventHandler(this.btDasturlash_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::Kutubxona.Properties.Resources.Screenshot_20231211_211525_Chrome;
            this.pictureBox3.Location = new System.Drawing.Point(961, 48);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(274, 164);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 4;
            this.pictureBox3.TabStop = false;
            // 
            // btk_oliw
            // 
            this.btk_oliw.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btk_oliw.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btk_oliw.ForeColor = System.Drawing.Color.Black;
            this.btk_oliw.Location = new System.Drawing.Point(145, 604);
            this.btk_oliw.Name = "btk_oliw";
            this.btk_oliw.Size = new System.Drawing.Size(274, 60);
            this.btk_oliw.TabIndex = 7;
            this.btk_oliw.Text = "Kitoblarni olish";
            this.btk_oliw.UseVisualStyleBackColor = false;
            this.btk_oliw.Click += new System.EventHandler(this.btk_oliw_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Kutubxona.Properties.Resources.Screenshot_20231211_212444_Google;
            this.pictureBox4.Location = new System.Drawing.Point(145, 434);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(274, 164);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 6;
            this.pictureBox4.TabStop = false;
            // 
            // btk_qaytarish
            // 
            this.btk_qaytarish.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btk_qaytarish.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btk_qaytarish.ForeColor = System.Drawing.Color.Black;
            this.btk_qaytarish.Location = new System.Drawing.Point(558, 604);
            this.btk_qaytarish.Name = "btk_qaytarish";
            this.btk_qaytarish.Size = new System.Drawing.Size(274, 60);
            this.btk_qaytarish.TabIndex = 9;
            this.btk_qaytarish.Text = "Kitoblarni qaytarish";
            this.btk_qaytarish.UseVisualStyleBackColor = false;
            this.btk_qaytarish.Click += new System.EventHandler(this.btk_qaytarish_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::Kutubxona.Properties.Resources.Screenshot_20231211_213025_Google;
            this.pictureBox5.Location = new System.Drawing.Point(558, 434);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(274, 164);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 8;
            this.pictureBox5.TabStop = false;
            // 
            // btm_book
            // 
            this.btm_book.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btm_book.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btm_book.ForeColor = System.Drawing.Color.Black;
            this.btm_book.Location = new System.Drawing.Point(961, 604);
            this.btm_book.Name = "btm_book";
            this.btm_book.Size = new System.Drawing.Size(274, 60);
            this.btm_book.TabIndex = 11;
            this.btm_book.Text = "Math books";
            this.btm_book.UseVisualStyleBackColor = false;
            this.btm_book.Click += new System.EventHandler(this.btm_book_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::Kutubxona.Properties.Resources.Screenshot_20231211_211937_Google;
            this.pictureBox6.Location = new System.Drawing.Point(961, 434);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(274, 164);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 10;
            this.pictureBox6.TabStop = false;
            // 
            // Ma_lumotlar_bazasi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Kutubxona.Properties.Resources.Screenshot_20231209_200334_Google;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1325, 759);
            this.Controls.Add(this.btm_book);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.btk_qaytarish);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.btk_oliw);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.btDasturlash);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.btArxiv_Statistic);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.btkitoblar);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Ma_lumotlar_bazasi";
            this.Text = "Ma_lumotlar_bazasi";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btkitoblar;
        private System.Windows.Forms.Button btArxiv_Statistic;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btDasturlash;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button btk_oliw;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Button btk_qaytarish;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Button btm_book;
        private System.Windows.Forms.PictureBox pictureBox6;
    }
}