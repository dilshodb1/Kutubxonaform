﻿namespace Kutubxona
{
    partial class Ar_St_2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbFullName = new System.Windows.Forms.Label();
            this.lbDepartureCity = new System.Windows.Forms.Label();
            this.lbDestinationCity = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lbTripDates = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lbDocumentNo = new System.Windows.Forms.Label();
            this.lbChangeDoc = new System.Windows.Forms.Label();
            this.lbDocExpDate = new System.Windows.Forms.Label();
            this.lbChangeDocExpDate = new System.Windows.Forms.Label();
            this.lbBaggageWeight = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.btDone = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(78, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(1313, 45);
            this.label3.TabIndex = 10;
            this.label3.Text = "Congratulations, you have booked a ticket. Please chech mail and Confirm";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(106, 110);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(218, 45);
            this.label1.TabIndex = 11;
            this.label1.Text = "Full Name :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(106, 212);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(315, 45);
            this.label2.TabIndex = 12;
            this.label2.Text = "Departure Time :";
            // 
            // lbFullName
            // 
            this.lbFullName.AutoSize = true;
            this.lbFullName.BackColor = System.Drawing.Color.White;
            this.lbFullName.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbFullName.Location = new System.Drawing.Point(591, 110);
            this.lbFullName.Name = "lbFullName";
            this.lbFullName.Size = new System.Drawing.Size(218, 45);
            this.lbFullName.TabIndex = 13;
            this.lbFullName.Text = "Full Name :";
            // 
            // lbDepartureCity
            // 
            this.lbDepartureCity.AutoSize = true;
            this.lbDepartureCity.BackColor = System.Drawing.Color.White;
            this.lbDepartureCity.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbDepartureCity.Location = new System.Drawing.Point(591, 212);
            this.lbDepartureCity.Name = "lbDepartureCity";
            this.lbDepartureCity.Size = new System.Drawing.Size(218, 45);
            this.lbDepartureCity.TabIndex = 14;
            this.lbDepartureCity.Text = "Full Name :";
            // 
            // lbDestinationCity
            // 
            this.lbDestinationCity.AutoSize = true;
            this.lbDestinationCity.BackColor = System.Drawing.Color.White;
            this.lbDestinationCity.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbDestinationCity.Location = new System.Drawing.Point(591, 313);
            this.lbDestinationCity.Name = "lbDestinationCity";
            this.lbDestinationCity.Size = new System.Drawing.Size(218, 45);
            this.lbDestinationCity.TabIndex = 16;
            this.lbDestinationCity.Text = "Full Name :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(106, 313);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(339, 45);
            this.label7.TabIndex = 15;
            this.label7.Text = "Destination Time :";
            // 
            // lbTripDates
            // 
            this.lbTripDates.AutoSize = true;
            this.lbTripDates.BackColor = System.Drawing.Color.White;
            this.lbTripDates.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbTripDates.Location = new System.Drawing.Point(591, 426);
            this.lbTripDates.Name = "lbTripDates";
            this.lbTripDates.Size = new System.Drawing.Size(218, 45);
            this.lbTripDates.TabIndex = 18;
            this.lbTripDates.Text = "Full Name :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(106, 426);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(232, 45);
            this.label9.TabIndex = 17;
            this.label9.Text = "Trip Dates : ";
            // 
            // lbDocumentNo
            // 
            this.lbDocumentNo.AutoSize = true;
            this.lbDocumentNo.BackColor = System.Drawing.Color.White;
            this.lbDocumentNo.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbDocumentNo.Location = new System.Drawing.Point(591, 547);
            this.lbDocumentNo.Name = "lbDocumentNo";
            this.lbDocumentNo.Size = new System.Drawing.Size(218, 45);
            this.lbDocumentNo.TabIndex = 20;
            this.lbDocumentNo.Text = "Full Name :";
            // 
            // lbChangeDoc
            // 
            this.lbChangeDoc.AutoSize = true;
            this.lbChangeDoc.BackColor = System.Drawing.Color.White;
            this.lbChangeDoc.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbChangeDoc.Location = new System.Drawing.Point(106, 547);
            this.lbChangeDoc.Name = "lbChangeDoc";
            this.lbChangeDoc.Size = new System.Drawing.Size(277, 45);
            this.lbChangeDoc.TabIndex = 19;
            this.lbChangeDoc.Text = "Document No :";
            // 
            // lbDocExpDate
            // 
            this.lbDocExpDate.AutoSize = true;
            this.lbDocExpDate.BackColor = System.Drawing.Color.White;
            this.lbDocExpDate.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbDocExpDate.Location = new System.Drawing.Point(591, 660);
            this.lbDocExpDate.Name = "lbDocExpDate";
            this.lbDocExpDate.Size = new System.Drawing.Size(218, 45);
            this.lbDocExpDate.TabIndex = 22;
            this.lbDocExpDate.Text = "Full Name :";
            // 
            // lbChangeDocExpDate
            // 
            this.lbChangeDocExpDate.AutoSize = true;
            this.lbChangeDocExpDate.BackColor = System.Drawing.Color.White;
            this.lbChangeDocExpDate.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbChangeDocExpDate.Location = new System.Drawing.Point(106, 660);
            this.lbChangeDocExpDate.Name = "lbChangeDocExpDate";
            this.lbChangeDocExpDate.Size = new System.Drawing.Size(443, 45);
            this.lbChangeDocExpDate.TabIndex = 21;
            this.lbChangeDocExpDate.Text = "Document Expiry Date : ";
            // 
            // lbBaggageWeight
            // 
            this.lbBaggageWeight.AutoSize = true;
            this.lbBaggageWeight.BackColor = System.Drawing.Color.White;
            this.lbBaggageWeight.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbBaggageWeight.Location = new System.Drawing.Point(591, 758);
            this.lbBaggageWeight.Name = "lbBaggageWeight";
            this.lbBaggageWeight.Size = new System.Drawing.Size(218, 45);
            this.lbBaggageWeight.TabIndex = 24;
            this.lbBaggageWeight.Text = "Full Name :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.White;
            this.label15.Font = new System.Drawing.Font("Arial Black", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.Location = new System.Drawing.Point(106, 758);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(336, 45);
            this.label15.TabIndex = 23;
            this.label15.Text = "Baggage  Weight :";
            // 
            // btDone
            // 
            this.btDone.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btDone.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btDone.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btDone.Location = new System.Drawing.Point(0, 915);
            this.btDone.Name = "btDone";
            this.btDone.Size = new System.Drawing.Size(1445, 61);
            this.btDone.TabIndex = 25;
            this.btDone.Text = "Done";
            this.btDone.UseVisualStyleBackColor = false;
            this.btDone.Click += new System.EventHandler(this.btDone_Click);
            // 
            // Ar_St_2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(19F, 37F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Kutubxona.Properties.Resources.Screenshot_20231211_213810_Google;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1445, 976);
            this.Controls.Add(this.btDone);
            this.Controls.Add(this.lbBaggageWeight);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.lbDocExpDate);
            this.Controls.Add(this.lbChangeDocExpDate);
            this.Controls.Add(this.lbDocumentNo);
            this.Controls.Add(this.lbChangeDoc);
            this.Controls.Add(this.lbTripDates);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lbDestinationCity);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lbDepartureCity);
            this.Controls.Add(this.lbFullName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label3);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "Ar_St_2";
            this.Text = "Ar_St_2";
            this.Load += new System.EventHandler(this.Ar_St_2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbFullName;
        private System.Windows.Forms.Label lbDepartureCity;
        private System.Windows.Forms.Label lbDestinationCity;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbTripDates;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lbDocumentNo;
        private System.Windows.Forms.Label lbChangeDoc;
        private System.Windows.Forms.Label lbDocExpDate;
        private System.Windows.Forms.Label lbChangeDocExpDate;
        private System.Windows.Forms.Label lbBaggageWeight;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btDone;
    }
}