﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kutubxona
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Ma_lumotlar_bazasi ob1 = new Ma_lumotlar_bazasi();
            if (tblogin.Text == "1234"  &&  tbparol.Text == "11218")
            {
                ob1.Show();
            }
            else
            {
                MessageBox.Show("Login yoki parol xato kiritilgan! Iltimos qaytadan kiriting!");
                tblogin.Text = " ";
                tbparol.Text = " ";
            }
            //if (tblogin.Text == "mamatovabrorjon" && tbparol.Text == "0101m")
            //{
            //    ob1.Show();
            //}
            //else
            //{
            //    MessageBox.Show("Login yoki parol xato kiritilgan! Iltimos qaytadan kiriting!");
            //    tblogin.Text = " ";
            //    tbparol.Text = " ";
            //}
            //if (tblogin.Text == "xoliqovabdijalil" && tbparol.Text == "0405m")
            //{
            //    ob1.Show();
            //}
            //else
            //{
            //    MessageBox.Show("Login yoki parol xato kiritilgan! Iltimos qaytadan kiriting!");
            //    tblogin.Text = " ";
            //    tbparol.Text = " ";
            //}
            //if (tblogin.Text == "baratovadurdona" && tbparol.Text == "dur19")
            //{
            //    ob1.Show();
            //}
            //else
            //{
            //    MessageBox.Show("Login yoki parol xato kiritilgan! Iltimos qaytadan kiriting!");
            //    tblogin.Text = " ";
            //    tbparol.Text = " ";
            //}
        }
    }
}
