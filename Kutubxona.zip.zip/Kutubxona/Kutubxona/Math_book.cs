﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kutubxona
{
    public partial class Math_book : Form
    {
        private DataTable dtCourses = new DataTable();
        private DataTable dtSelectedCourses = new DataTable();

        public Math_book()
        {
            InitializeComponent();
        }

        private void Math_book_Load(object sender, EventArgs e)
        {
            SelectedCoursesTable();
            FillCoursesTable();

            listBox1.DataSource = dtCourses;
            listBox1.DisplayMember = "CourseName";
            listBox2.DataSource = dtSelectedCourses;
            listBox2.DisplayMember = "CourseName";
        }
        private void FillCoursesTable()
        {
            dtCourses.Columns.Add("CourseID", typeof(int));
            dtCourses.Columns.Add("CourseName");
            dtCourses.Columns.Add("CourseDuration");

            dtCourses.Rows.Add(1, "Diffenersal tenglamalar", "4 Month");
            dtCourses.Rows.Add(2, "Matematik analiz asoslari", "6 Month");
            dtCourses.Rows.Add(3, "Funksional ketma - ketliklar", "6 Month");
            dtCourses.Rows.Add(4, "Dimidovich masalalar to'plami", "5 Month");
            dtCourses.Rows.Add(5, "Elementar matematika", "3 Month");
            dtCourses.Rows.Add(6, "Logika savollar to'plami", "5 Month");
            dtCourses.Rows.Add(7, "Murakkab funksiyalar hosilasi", "3 Month");
            dtCourses.Rows.Add(8, "Turkcha IQ", "4 Month");
            dtCourses.Rows.Add(9, "Triganometriya va Uchburchaklar", "3 Month");
            dtCourses.Rows.Add(10, "Geometriya nazariya va masalar", "5 Month");
        }

        private void SelectedCoursesTable()
        {
            dtSelectedCourses.Columns.Add("CourseID", typeof(int));
            dtSelectedCourses.Columns.Add("CourseName");
            dtSelectedCourses.Columns.Add("CourseDuration");
        }

      
        private void btnfinalize_Click(object sender, EventArgs e)
        {
            DialogResult dialog = MessageBox.Show("Are you Sure you want to finalize the Selected Courses", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialog == DialogResult.Yes)
            {
                dataGridView1.DataSource = dtSelectedCourses;
                dataGridView1.Enabled = false;
                dataGridView1.Columns[0].Visible = false;
                dataGridView1.RowHeadersVisible = false;
                dataGridView1.Columns[1].Width = 350;
                dataGridView1.Columns[2].Width = 500;
            }
            else
            {
                MessageBox.Show("Please select al least one course.", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (listBox1.Items.Count > 0)
            {
                dtSelectedCourses.ImportRow(dtCourses.Rows[listBox1.SelectedIndex]);
                dtCourses.Rows[listBox1.SelectedIndex].Delete();
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (listBox2.Items.Count > 0)
            {
                dtSelectedCourses.ImportRow(dtCourses.Rows[listBox2.SelectedIndex]);
                dtCourses.Rows[listBox2.SelectedIndex].Delete();
            }
        }

        private void btnAddAll_Click(object sender, EventArgs e)
        {
            if (listBox1.Items.Count > 0)
            {
                int Count = dtCourses.Rows.Count;
                for (int i = Count - 1; i >= 0; i--)
                {
                    dtSelectedCourses.ImportRow(dtCourses.Rows[listBox1.SelectedIndex]);
                    dtCourses.Rows[listBox1.SelectedIndex].Delete();
                }
            }
        }

        private void btnRemoveAll_Click(object sender, EventArgs e)
        {
            if (listBox2.Items.Count > 0)
            {
                int Count = dtSelectedCourses.Rows.Count;
                for (int i = Count - 1; i >= 0; i--)
                {
                    dtCourses.ImportRow(dtSelectedCourses.Rows[listBox2.SelectedIndex]);
                    dtSelectedCourses.Rows[listBox2.SelectedIndex].Delete();
                }
            }
        }
    }
}
