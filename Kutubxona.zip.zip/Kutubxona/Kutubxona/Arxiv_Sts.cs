﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kutubxona
{
    public partial class Arxiv_Sts : Form
    {
        public static Boolean Passport, IDCard;
        public static string To, From, StartTripDate, EndTripDate, firstName, LastName, DocumentNo, IssuDate, Expirydate, WeightBaggage;

        public Arxiv_Sts()
        {
            InitializeComponent();
        }

        private void Arxiv_Sts_Load(object sender, EventArgs e)
        {
            monthCalendar1.MaxSelectionCount = 100;
            monthCalendar1.ShowToday = true;

            numericUpDown1.Increment = 5;
            numericUpDown1.ReadOnly = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            To = txtTo.Text;
            From = txtFrom.Text;

            StartTripDate = monthCalendar1.SelectionStart.ToString("dd MMM yyy");
            EndTripDate = monthCalendar1.SelectionEnd.ToString("dd MMM yyy");

            firstName = txtFirstName.Text;
            LastName = txtLastName.Text;
            DocumentNo = txtDocumentNo.Text;

            IssuDate = dtpicker.Value.ToString("dd MMM yyy");
            Expirydate = dateTimePicker1.Value.ToString("dd MMM yyy");
            WeightBaggage = numericUpDown1.Value.ToString();

            this.Hide();
            Ar_St_2 ff2 = new Ar_St_2();
            ff2.Show();
        }

        private void rdbPassport_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbPassport.Checked)
            {
                lbDocNo.Text = "Passport No : ";
                lbIssueDate.Text = "Passport Issue Date : ";
                lbExpiryDate.Text = "Passport Expiry Date : ";

                Passport = true;
            }
            else
            {
                Passport = false;
            }
        }

        private void rdbIdcard_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbIdcard.Checked)
            {
                lbDocNo.Text = "Id Card No : ";
                lbIssueDate.Text = "Id Card Issue Date : ";
                lbExpiryDate.Text = "Id Card Expiry Date : ";

                IDCard = true;
            }
            else
            {
                IDCard = false;
            }
        }

        private void dtpicker_ValueChanged(object sender, EventArgs e)
        {
            DateTime dt = dtpicker.Value;
            dateTimePicker1.MinDate = dt;
        }
    }
}
