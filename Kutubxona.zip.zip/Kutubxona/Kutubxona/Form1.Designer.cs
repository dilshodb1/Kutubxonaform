﻿namespace Kutubxona
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.tblogin = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblogin = new System.Windows.Forms.Label();
            this.lbparol = new System.Windows.Forms.Label();
            this.tbparol = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.BackgroundImage = global::Kutubxona.Properties.Resources.Screenshot_20231209_200334_Google;
            this.button1.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(968, 679);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(236, 67);
            this.button1.TabIndex = 0;
            this.button1.Text = "KIRISH";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tblogin
            // 
            this.tblogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tblogin.Location = new System.Drawing.Point(297, 282);
            this.tblogin.Name = "tblogin";
            this.tblogin.PasswordChar = '*';
            this.tblogin.Size = new System.Drawing.Size(290, 44);
            this.tblogin.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lucida Handwriting", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(529, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(588, 48);
            this.label1.TabIndex = 2;
            this.label1.Text = "Kutubxonaga kirish qismi";
            // 
            // lblogin
            // 
            this.lblogin.AutoSize = true;
            this.lblogin.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.lblogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblogin.Location = new System.Drawing.Point(98, 284);
            this.lblogin.Name = "lblogin";
            this.lblogin.Size = new System.Drawing.Size(115, 42);
            this.lblogin.TabIndex = 3;
            this.lblogin.Text = "Login";
            // 
            // lbparol
            // 
            this.lbparol.AutoSize = true;
            this.lbparol.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.lbparol.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbparol.Location = new System.Drawing.Point(98, 358);
            this.lbparol.Name = "lbparol";
            this.lbparol.Size = new System.Drawing.Size(110, 42);
            this.lbparol.TabIndex = 5;
            this.lbparol.Text = "Parol";
            // 
            // tbparol
            // 
            this.tbparol.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbparol.Location = new System.Drawing.Point(297, 356);
            this.tbparol.Name = "tbparol";
            this.tbparol.PasswordChar = '*';
            this.tbparol.Size = new System.Drawing.Size(290, 44);
            this.tbparol.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Kutubxona.Properties.Resources.Screenshot_20231209_200334_Google;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1232, 769);
            this.Controls.Add(this.lbparol);
            this.Controls.Add(this.tbparol);
            this.Controls.Add(this.lblogin);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tblogin);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox tblogin;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblogin;
        private System.Windows.Forms.Label lbparol;
        private System.Windows.Forms.TextBox tbparol;
    }
}

