﻿namespace Kutubxona
{
    partial class Badiiy_kitoblar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.txtJanr = new System.Windows.Forms.TextBox();
            this.txtMualif = new System.Windows.Forms.TextBox();
            this.txtKitob = new System.Windows.Forms.TextBox();
            this.lblHolati = new System.Windows.Forms.Label();
            this.lblJanr = new System.Windows.Forms.Label();
            this.lblMualif = new System.Windows.Forms.Label();
            this.lblKitobNomi = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(626, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.Size = new System.Drawing.Size(570, 215);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Location = new System.Drawing.Point(72, 266);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1084, 391);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox4.Location = new System.Drawing.Point(405, 565);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(677, 44);
            this.textBox4.TabIndex = 20;
            // 
            // txtJanr
            // 
            this.txtJanr.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtJanr.Location = new System.Drawing.Point(405, 484);
            this.txtJanr.Name = "txtJanr";
            this.txtJanr.Size = new System.Drawing.Size(677, 44);
            this.txtJanr.TabIndex = 19;
            // 
            // txtMualif
            // 
            this.txtMualif.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtMualif.Location = new System.Drawing.Point(405, 402);
            this.txtMualif.Name = "txtMualif";
            this.txtMualif.Size = new System.Drawing.Size(677, 44);
            this.txtMualif.TabIndex = 18;
            // 
            // txtKitob
            // 
            this.txtKitob.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtKitob.Location = new System.Drawing.Point(405, 319);
            this.txtKitob.Name = "txtKitob";
            this.txtKitob.Size = new System.Drawing.Size(677, 44);
            this.txtKitob.TabIndex = 17;
            // 
            // lblHolati
            // 
            this.lblHolati.AutoSize = true;
            this.lblHolati.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lblHolati.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblHolati.Location = new System.Drawing.Point(151, 572);
            this.lblHolati.Name = "lblHolati";
            this.lblHolati.Size = new System.Drawing.Size(105, 37);
            this.lblHolati.TabIndex = 16;
            this.lblHolati.Text = "Holati";
            // 
            // lblJanr
            // 
            this.lblJanr.AutoSize = true;
            this.lblJanr.BackColor = System.Drawing.Color.Transparent;
            this.lblJanr.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblJanr.Location = new System.Drawing.Point(151, 484);
            this.lblJanr.Name = "lblJanr";
            this.lblJanr.Size = new System.Drawing.Size(92, 37);
            this.lblJanr.TabIndex = 15;
            this.lblJanr.Text = "Janri";
            // 
            // lblMualif
            // 
            this.lblMualif.AutoSize = true;
            this.lblMualif.BackColor = System.Drawing.Color.Transparent;
            this.lblMualif.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblMualif.Location = new System.Drawing.Point(151, 409);
            this.lblMualif.Name = "lblMualif";
            this.lblMualif.Size = new System.Drawing.Size(124, 37);
            this.lblMualif.TabIndex = 14;
            this.lblMualif.Text = "Muallifi";
            // 
            // lblKitobNomi
            // 
            this.lblKitobNomi.AutoSize = true;
            this.lblKitobNomi.BackColor = System.Drawing.Color.Transparent;
            this.lblKitobNomi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblKitobNomi.Location = new System.Drawing.Point(151, 323);
            this.lblKitobNomi.Name = "lblKitobNomi";
            this.lblKitobNomi.Size = new System.Drawing.Size(179, 37);
            this.lblKitobNomi.TabIndex = 13;
            this.lblKitobNomi.Text = "Kitob nomi";
            // 
            // Badiiy_kitoblar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Kutubxona.Properties.Resources.Screenshot_20231209_200857_Google;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1199, 690);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.txtJanr);
            this.Controls.Add(this.txtMualif);
            this.Controls.Add(this.txtKitob);
            this.Controls.Add(this.lblHolati);
            this.Controls.Add(this.lblJanr);
            this.Controls.Add(this.lblMualif);
            this.Controls.Add(this.lblKitobNomi);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Badiiy_kitoblar";
            this.Text = "Badiiy_kitoblar";
            this.Load += new System.EventHandler(this.Badiiy_kitoblar_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox txtJanr;
        private System.Windows.Forms.TextBox txtMualif;
        private System.Windows.Forms.TextBox txtKitob;
        private System.Windows.Forms.Label lblHolati;
        private System.Windows.Forms.Label lblJanr;
        private System.Windows.Forms.Label lblMualif;
        private System.Windows.Forms.Label lblKitobNomi;
    }
}