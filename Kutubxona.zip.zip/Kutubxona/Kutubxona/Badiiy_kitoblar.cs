﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Kutubxona
{
    public partial class Badiiy_kitoblar : Form
    {
        public Badiiy_kitoblar()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data 
Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\1\Desktop\SQLManagementStudio_x64_RUS");

        public void Clear()
        {
            txtKitob.Clear();
            txtMualif.Clear();
            txtJanr.Clear();
            textBox4.Clear();
        }


        private void Badiiy_kitoblar_Load(object sender, EventArgs e)
        {
            Display();
        }

        private void Display()
        {
            con.Open();
            string query = "SELECT * FROM talaba";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder build = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            con.Close();
            Clear();

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (txtKitob.Text == "" || txtMualif.Text == "" || txtJanr.Text == "" ||textBox4.Text == "")
            {
                MessageBox.Show("Ma'lumotlarni to'ldiring !");
            }
            else
            {
                con.Open();
                string query = "insert into kitob values('" + txtKitob.Text.ToUpper() + "','" + txtMualif.Text.ToUpper() +
               "','" + txtJanr.Text.ToUpper() + "','" + textBox4.Text + "')";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Kitoblar jadvaliga kitob muvaffaqiyatli qo'shildi", "Add");
                con.Close();
                Display();
            }
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int id;
            id = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value);
            txtKitob.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtMualif.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            txtJanr.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
            textBox4.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
        }
    }
}
